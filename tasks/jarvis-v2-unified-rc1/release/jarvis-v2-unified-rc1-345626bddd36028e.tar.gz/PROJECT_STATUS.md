# JARVIS Project Status

Current release candidate: [unified offline RC1](tasks/jarvis-v2-unified-rc1/REPORT.md).
The predecessor [release-readiness packet](tasks/jarvis-v2-release-readiness-r1/REPORT.md)
and [security-remediation packet](tasks/jarvis-security-remediation-r1/REPORT.md) remain preserved.
Authority routes now require credentials even on loopback. Real execution stays
disabled. See [the candidate contract and limits](docs/release_candidate.md).
Earlier sprint and live-suite results below retain their historical source scope.


Current offline application milestone: [secure execution integration and readiness](tasks/jarvis-end-to-end-readiness-r1/REPORT.md).
The actual application now integrates signed synthetic IPC, durable receipts and
explicit offline recovery. Real tools, confirmation dispatch, dictation effects
and host resource mutation controls are closed. Older live-readiness and tool
results below describe historical source, not this release's live authorization.
See [the current execution/operator contract](docs/end_to_end_readiness.md).


Latest offline sprint: [durable recovery decisions and protected witness renewal](tasks/jarvis-recovery-decisions-r1/REPORT.md).
Separate SQLite/protected journals retain verified proposals, authenticated synthetic
decisions and receipts; restart rechecks both HMAC keys and original UUID/payload
bindings. Witnesses advance against externally retained ancestry without activating
restored tasks. Detailed history requires operator authentication; readiness exposes
aggregate counts. Source-bound new results and remaining limits are in that report.

Previous source/offline sprint: [authority enrollment and branch verification](tasks/jarvis-authority-enrollment-r1/REPORT.md).
Normal Authority opens refuse missing/incomplete stores and implicit legacy
approval. An explicit disposable offline ceremony creates authenticated genesis,
durable receipts and an external witness; restart verifies custody and continuity.
Read-only restored-branch verification emits a proposal with no activation.
Unprovisioned default startup now fails closed; trusted embedding/key/witness
provisioning is an activation prerequisite. UNKNOWN work remains unresolved.
Exact current tests, crash evidence, benchmarks and limitations are in the report;
earlier entries below retain their historical source/evidence scope.

Latest audit durability sprint (2026-11-05 America/Chicago; UTC evidence
2026-11-06): [audit disaster recovery](tasks/jarvis-audit-disaster-recovery-r1/REPORT.md).
Implemented opt-in same-key checkpoint generations, independently supplied trust
references, durable export attestations, verified transactional reconstruction
and authenticated offline restore/reconciliation CLI. Restored artifacts remain
inert; UNKNOWN outcomes and all historical identities are preserved. Current
source-bound tests, independent review, bounded benchmarks and exact limitations
are in that report. No protected deletion, runtime migration or live activation.

Latest source/offline recovery sprint (2026-11-05 America/Chicago; UTC evidence
2026-11-06): [operator recovery and ledger report](tasks/jarvis-operator-ledger-r1/REPORT.md).
Implemented read-only authenticated diagnostics and quiesced CLI, opt-in protected
external HMAC checkpoints, bounded integrity-checked exports, audited local
recovery/archive preparation, and terminal history preservation on schedule stop.
No protected history deletion, real-store enrollment/migration or live execution.
Exact current counts, independent review, crash evidence and limitations are in
the new report; older entries below retain their historical evidence scope.

Latest offline engineering sprint (2026-11-05 America/Chicago; evidence UTC
2026-11-06): [offline execution report](tasks/jarvis-offline-execution-r1/REPORT.md).
The actual app now connects explicit synthetic task/schedule admission, simulated
capability policy, the fenced durable queue, bounded worker, durable result and
receipt publication, API/CLI/reporter status, cancellation, sleep/stop/wake and
restart reconciliation. New public mutation IDs are canonical UUID4; deterministic
internal UUID5 receipts are reserved. No public completion endpoint was added.
Real executor registration is rejected. No production service, real state migration,
provider, broker, infrastructure, credentials or Gate6K activity was enabled.
Final exact source-bound counts and remaining limits are in the new report;
all earlier paragraphs below describe their historical implementation versions.


Latest first-party compatibility continuation (2026-10-31):
[`tasks/jarvis-client-compatibility-deliverable-r1/JARVIS-CONSOLIDATED-REPORT.md`](tasks/jarvis-client-compatibility-deliverable-r1/JARVIS-CONSOLIDATED-REPORT.md)
consolidates prior durability/readiness and the scoped143-file caller inventory.
No first-party task/schedule mutation client exists; external adapters remain a
rollout gate. The actual read-only reporter and its existing test file now show
admitted/held, UNKNOWN, cancel_requested, simulation and unavailable states honestly.
Ten focused actual-reader cases pass with no real sends; only reporter.py changed
among application files. The eight reviewed backend files and prior840451e8... seal
are unchanged; prior80 backend/full-app evidence is preserved, not rerun or summed.
Active client/Hermes/resource guidance is corrected. Real execution/production,
identities/permissions/credentials, PVE/guest/live/Gate6K remain unmodified/disabled.
No security stage is actionable until restricted Nexus execution identities/path
and trusted guest/bootstrap/grant bindings exist; this document approves none.
Earlier continuity entries below retain their historical source/evidence scope.


Current source/offline milestone (2026-10-31):
[`tasks/jarvis-authority-readiness-r1/REPORT.md`](tasks/jarvis-authority-readiness-r1/REPORT.md)
contains the implemented single-writer SQLite task/scheduler authority, durable
receipts/occurrences/outbox, explicit migration, truthful cancellation and test-only
simulation. Final80 focused cases pass (zero skips), including8 independent-process
cases; the actual existing app.main/server lifespan and native dependency checks
pass under synthetic offline configuration with a fresh exact28-wheel target.
Eight current source hashes have independent gpt-6-astra/high static closure.
Real execution, production startup/migration, broker wiring/activation, permissions,
guest changes and privileged Gate6K remain disabled/unperformed. Overdue schedules
require explicit owner-quiesced recovery; this is not power-loss/live-isolation proof.
The report contains ONE staged eventual-live proposal and remaining actual-principal/
guest/bootstrap facts. Earlier continuity sections below are historical source and
evidence versions; their limitations are superseded only where this new report proves it.


Consolidated review (2026-10-30):
[`tasks/jarvis-consolidated-review-r1/REVIEW.md`](tasks/jarvis-consolidated-review-r1/REVIEW.md)
binds the current dirty source, per-milestone evidence, overlapping test scopes,
remaining technical gaps and pending setup/activation gates. Code was unchanged
during consolidation; the proposed isolated integration environment was not created.

Current offline continuation (2026-10-30): see
[`tasks/proxmox-automation-phase3-review-r1/PROGRESS.md`](tasks/proxmox-automation-phase3-review-r1/PROGRESS.md)
for the independently reviewed serial-broker revision, source/test identities,
conditional setup request and TaskQueue persistence reliability work. This is
source/offline validation only; no guest/production activation or privileged
Gate6K qualification is authorized or claimed. Earlier results below are historical.

Successor core reliability: see
[`tasks/jarvis-v2-taskqueue-reliability-r2/README.md`](tasks/jarvis-v2-taskqueue-reliability-r2/README.md)
for bounded identifier collision handling, damaged-store write protection and
29 focused methods/65 subtests. Independent stale writers remain unsupported.
Public historical source/dependency identity verification is recorded separately in
[`tasks/jarvis-offline-provenance-r1/`](tasks/jarvis-offline-provenance-r1/);
the historical 7741-pass/11-deselected baseline is not a current-checkout result.

TaskQueue caller successor: see
[`tasks/jarvis-v2-taskqueue-callers-r3/README.md`](tasks/jarvis-v2-taskqueue-callers-r3/README.md)
for explicit API publication/audit outcomes, scheduler enqueue timestamp ordering,
42 methods/82 subtests and the source-only ownership/multiwriter design map.

Scheduler successor: see
[`tasks/jarvis-v2-scheduler-reliability-r4/README.md`](tasks/jarvis-v2-scheduler-reliability-r4/README.md)
for atomic scheduled-job publication, explicit applied/uncertain outcomes,
disabled/stale lifecycle admission checks and39 methods/54 subtests. Already-admitted
enqueues are not canceled; no real framework/service integration ran.

Last verified: 2026-05-30

## Current Real Project State

JARVIS is a local-first Python/FastAPI assistant backend with Ollama-based LLM routing, a modular tool registry, local audit logging, basic task/scheduler APIs, procedural memory, optional disabled-by-default memory backends, voice pipeline components, and desktop/mobile HUD frontends.

The project is not a fully complete always-on assistant yet. Phase 0-3 surfaces are usable or partially usable. The Phase 4 early local track is implemented behind config flags where needed; hardware-heavy, credentialed, or external-runtime integrations remain explicit stubs until the dedicated server and live services are available.

Default access policy is localhost-only:

- `config.yaml` and `config.yaml.example` now bind `server.host` to `127.0.0.1`.
- Non-loopback hosts such as `0.0.0.0` are rejected unless `server.remote_access_enabled: true`.
- API startup does not start the microphone, wake-word loop, voice pipeline, or hotkey listener by default.
- Future remote access should be enabled intentionally through Tailscale, not open LAN binding.

## What Works

- FastAPI app import and route definitions: `app/main.py`, `app/server.py`.
- REST health routes: `/health`, `/health/tools`, `/health/readiness`.
- Chat route with intent routing, direct replies, Ollama fallback handling, tool dispatch, dry-run narration, and confirmation gates.
- WebSocket route at configured `server.websocket_path`.
- Tool registry: browser, web search, apps, files, shell, calendar, screenshot, system stats, mouse/keyboard, vision wrapper, Obsidian, browser-use plan stub, Kasa status/control stub, CAD plan stub, CLI readiness stub, and MCP wrapper stub.
- Browser routing for URL/domain requests such as `open google.com`.
- Screenshot and screen/webcam vision tool path, assuming local dependencies, screen/camera access, Ollama, and the configured vision model are available.
- Procedural memory route backed by `skills.md`.
- Dictation mode routes a separate hotkey path through STT to clipboard and optional type-out without brain, LLM, TTS, or raw transcript audit logging.
- Obsidian vault tool can create, append, read, and search notes inside `jarvis-vault/`, with optional obsidian-mcp handoff still stubbed.
- Embedding-based tool selection is implemented as a feature-flagged second pass and defaults OFF.
- Graphiti + Neo4j temporal memory client, compose service shape, and REST endpoints are implemented behind `memory.graphiti_enabled=false` by default.
- Task queue and scheduler API surfaces.
- Resource-management runtime states and commands: ACTIVE, LIGHT_SLEEP, DEEP_SLEEP, WAKING, `jarvis sleep --light`, `jarvis sleep --deep`, `jarvis wake`, `jarvis status`, and `jarvis shutdown`.
- PWA static mount at `/pwa`.
- Electron HUD files and package metadata.
- Tailscale status helper.
- Readiness report and tool readiness smoke scripts.
- Docker build file now exists for the existing `docker-compose.yml`.

## What Partially Works

- Voice: wake word, VAD, STT, TTS, push-to-talk, and boot code exist, but live voice requires attended microphone/speaker validation. Backend API startup intentionally does not activate voice automatically.
- Vision: routing now calls the vision tool for `vision` intents, but useful output depends on a working screenshot/webcam path, Ollama availability, and `models.vision`.
- Memory: procedural memory works; Mem0, ChromaDB RAG, and Graphiti are disabled by default and return explicit stubs until packages/services and config flags are enabled.
- Scheduler: the API and APScheduler integration exist and now start during FastAPI lifespan, but real scheduled task behavior still needs long-running validation.
- Comms: Discord and Telegram modules exist but remain disabled until packages, tokens, channel IDs, and approval flows are configured.
- Tailscale/PWA: local PWA works as static assets; remote access remains an intentional future step.
- Docker Compose: now has a Dockerfile, loopback-bound published ports, and an Ollama service URL override. It still needs Docker/GPU validation on the target host.
- Resource savings: unload/stop logic is covered by mocks and can report live VRAM/RAM/process/CUDA context data, but real before/after savings still need a live Ollama + GPU idle run on the target host.

## Current Idle Resource Usage Targets

Measured live values are exposed by `jarvis status`; the table below describes the intended steady-state profile for each mode.

| Runtime state | Current expected JARVIS-owned resource profile |
|---------------|------------------------------------------------|
| ACTIVE | Normal FastAPI operation; scheduler running; normal Ollama keep_alive behavior; voice/STT/TTS/vision caches may be resident after use. |
| LIGHT_SLEEP | Ollama models unloaded, STT/TTS/vision caches released, voice pipeline stopped, scheduler stopped, audio mixer released, UI WebSockets closed; FastAPI and optional wake listener remain. |
| DEEP_SLEEP | LIGHT_SLEEP cleanup plus CLI process-stop pass for JARVIS-owned FastAPI/HUD/automation workers; automatic idle deep sleep exits FastAPI when `resource_mode.stop_server_on_auto_deep_sleep` is true; expected near-zero meaningful JARVIS-owned VRAM/RAM/CPU after process termination. |

Live check on 2026-05-14:

- Before deep sleep: `jarvis status` saw `qwen3-nothink:latest` and `gemma3:4b` loaded in Ollama, with 14,660.4 MB estimated loaded-model VRAM and 14,188 MB total system GPU memory in use. No JARVIS-owned processes were running.
- After `python -m app.cli sleep --deep`: loaded Ollama models dropped to 0, estimated loaded-model VRAM dropped to 0 MB, total system GPU memory in use dropped to 1,034 MB, JARVIS-owned process RSS/committed RAM stayed at 0 MB.
- Measured savings in this pass: 14,660.4 MB loaded-model VRAM and about 13,154 MB total GPU memory. JARVIS process RAM savings were 0 MB because the FastAPI/HUD/voice runtime was already offline before the command.

## What Is Stubbed

- Mem0 long-term memory unless `memory.mem0_enabled` and the package/service are configured.
- ChromaDB RAG unless `memory.chromadb_enabled` is true and the package/index paths are configured.
- Browser-use live execution. The tool returns action plans and avoids live browser-agent automation by default.
- Open computer-use live GUI automation.
- Kasa control writes and smart-device operation until real devices are selected.
- CAD/printing beyond design/export planning.
- MCP client calls beyond the whitelist/stub layer.
- UE5 MetaHuman, Audio2Face, and hologram external runtime wiring.
- Voice clone conditioning until a real private voice reference WAV exists.
- Hermes Agent. It is documented, but not active in the default app flow.
- OpenJarvis optimization until enough real traces exist.

## What Is Broken Or Blocked

- Dedicated server hardware is not installed, so 5090 model profile, always-on service behavior, GPU container validation, and full hardware validation are blocked.
- Live voice cannot be marked complete until an attended wake/PTT -> STT -> response -> TTS playback run passes.
- Docker was not validated in this pass because Docker is not available in the current environment.
- Ollama-dependent commands can fail if Ollama is not running or models are missing.
- Windows/NVIDIA shared GPU memory can remain visible after model unload because WDDM and the driver may retain reusable mappings; `jarvis status` should be used to check loaded Ollama models and JARVIS-owned CUDA contexts.
- Docker Compose needs target-host validation with NVIDIA container support before it can be considered deployment-ready.
- Historical loop logs still describe older phase states at the time they were written. Current truth should be `PROJECT_STATUS.md`, `tasks/todo.md`, `tasks/tool-readiness-inventory.md`, `README.md`, `config.yaml`, and tests.

## What Was Fixed During This Review

- `app/config.py`: added localhost-by-default validation and a container-friendly `JARVIS_OLLAMA_BASE_URL` override.
- `config.yaml`, `config.yaml.example`: switched server host to `127.0.0.1` and added explicit remote/voice/hotkey startup flags.
- `app/server.py`: moved startup checks into lifespan, starts/stops scheduler in lifespan, registers kill callbacks idempotently, and prevents default voice/hotkey startup.
- `app/main.py`: added a real `python -m app.main` uvicorn entry point and removed deprecated startup event usage.
- `app/brain/kill_switch.py`: made hotkey listener startup idempotent.
- `app/brain/router.py`: fixed URL/domain requests so they route to browser control instead of app launch or web search.
- `app/server.py`: wired `vision` intents to the vision tool and `retrieve_memory` intents to procedural/Mem0/RAG context.
- `app/memory/rag_client.py`: made ChromaDB obey `memory.chromadb_enabled` and use the configured collection name.
- `app/computer/vision.py`: hardened Ollama vision response parsing instead of assuming a `response` key exists.
- `.gitignore`: changed root runtime ignores so `app/logs/audit.py` and `app/logs/__init__.py` can be tracked.
- `requirements.txt`: added missing clean-clone dependencies for `pydantic-settings`, `apscheduler`, and `icalendar`.
- `Dockerfile`, `docker-compose.yml`: added a backend Dockerfile, loopback-only published ports, and container Ollama URL override.
- `app/resource_manager.py`, `app/cli.py`, `jarvis.py`, `jarvis.cmd`: added runtime resource-state transitions, Ollama unload/preload handling, process discovery/termination, resource reports, and the requested sleep/wake/status/shutdown commands.
- `app/server.py`: added resource endpoints, idle detection startup, WebSocket shutdown, light-sleep auto-wake for chat/WebSocket interactions, and deep-sleep refusal until manual wake.
- `app/voice/stt.py`, `app/voice/tts.py`, `app/voice/wake_word.py`, `app/voice/sounds.py`, `app/computer/vision.py`: added cleanup hooks for cached models, audio mixer resources, and lightweight wake listener behavior.
- `docs/resource_management.md`: documented light sleep vs deep sleep, Windows shared GPU memory behavior, cold-start wake behavior, and expected services per state.
- Pre-server cleanup: lazy-loaded tool modules, ChromaDB, APScheduler, Chatterbox, Kokoro, and the voice pipeline's server callbacks to reduce startup/import cost and idle memory pressure; tightened CLI status timeouts and wake-listener event-loop handoff.
- `frontend/pwa/manifest.json`: scoped PWA start URL to the `/pwa` mount.
- Tests: added coverage for localhost config validation, Docker/Ollama env override, disabled RAG behavior, vision intent wiring, memory intent wiring, PWA manifest scope, default lifespan behavior, and browser URL routing.
- Docs: updated README, 5090 migration notes, tool readiness inventory, CLAUDE status, and HANDOFF archive note.
- Local finish review on 2026-05-30: reconciled stale task/readiness/repo documentation after Dictation, Obsidian, embedding routing, and Graphiti had already landed; added a pre-server readiness runner for repeated local validation.

## Remaining Blockers

- Install and validate the dedicated server GPU/driver/CUDA/Ollama stack.
- Confirm the required Ollama models are pulled and usable on the final hardware.
- Run attended live voice validation with real microphone and speaker devices.
- Decide when to intentionally enable Tailscale remote access.
- Provide real comms tokens/channel IDs only when remote approval flows are ready.
- Provide a real voice clone WAV if Chatterbox voice conditioning is desired.
- Validate Docker Compose with NVIDIA runtime on the target machine.
- Run live ACTIVE -> LIGHT_SLEEP -> DEEP_SLEEP measurements on the target GPU host and record actual VRAM/RAM deltas from `jarvis status`.

## Hardware/Server-Dependent Tasks

- Switch model profile to the 5090 stack with `python scripts/switch_models.py --profile 5090`.
- Pull 32B and vision models on the server.
- Validate GPU memory, first-token latency, STT latency, and TTS playback.
- Decide whether the server hosts audio devices directly or receives audio from a client device.
- Enable Tailscale remote access only after local validation passes.
- Run long-lived scheduler and task queue validation.
- Validate UE5/Audio2Face/hologram external runtime paths if cinematic mode becomes a priority.

## Recommended Next Priorities

1. Run `python tasks/pre_server_readiness.py` before each pre-server handoff.
2. Run attended live voice smoke test on the current machine.
3. Validate live web search and Ollama vision behavior with the configured models/services running.
4. Decide whether browser-use should remain plan-only or be enabled for live browser-agent automation behind confirmation gates.
5. Validate Graphiti/Neo4j and Docker Compose on a machine with Docker and NVIDIA runtime.
6. After hardware install, switch model profile, retest clean clone, and only then enable Tailscale remote access.

## Exact Commands

Install backend:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Install Electron HUD dependencies:

```powershell
npm.cmd install --prefix frontend/electron
```

Run backend API locally:

```powershell
python -m app.main
```

Alternative backend command:

```powershell
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Run separate boot flow without automatically starting voice:

```powershell
python -m app.boot
```

Run Electron HUD:

```powershell
npm.cmd start --prefix frontend/electron
```

Open PWA after backend starts:

```text
http://127.0.0.1:8000/pwa/
```

Resource management:

```powershell
jarvis status
jarvis sleep --light
jarvis sleep --deep
jarvis wake
jarvis shutdown
```

From the repo without a PATH alias:

```powershell
.\jarvis.cmd status
python -m app.cli status
```

Run readiness checks:

```powershell
python tasks/pre_server_readiness.py
python tasks/readiness_report.py
python tasks/tool_readiness_smoke.py
```

Run focused stabilization tests:

```powershell
pytest -q tests/test_config_check.py tests/test_rag_client.py tests/test_server_integration.py tests/router_test.py tests/test_pwa_serve.py tests/test_readiness_report.py -p no:cacheprovider
```

Collect the full test suite:

```powershell
pytest --collect-only -q -p no:cacheprovider
```

Run the full suite:

```powershell
pytest -q -p no:cacheprovider
```

Run live voice validation when attended:

```powershell
python tasks/manual_voice_smoke.py --live --speak --listen-timeout 45
```

Run mock voice validation:

```powershell
python tasks/manual_voice_smoke.py --mock-pipeline
```

Run dependency checks:

```powershell
python -m pip check
npm.cmd audit --audit-level=moderate --prefix frontend/electron
```

Run Docker Compose when Docker/NVIDIA runtime is available:

```powershell
docker compose up --build
```

## Latest Validation Results

- 2026-07-02 remote session: all six Ollama env vars confirmed set at user scope and picked up by `ollama serve` (FLASH_ATTENTION=true, KV_CACHE_TYPE=q8_0, NUM_PARALLEL=2, NUM_BATCH=512, MAX_LOADED_MODELS=2, KEEP_ALIVE=-1) — the "requires Administrator shell" blocker no longer applies because user-scope vars cover a user-run Ollama. Live web search smoke passed with real DuckDuckGo results via `app.tools.web_search.execute`. Live vision smoke passed: qwen3-vl accurately described a live screen capture via `app.computer.vision.execute`. `npm audit` caught a new high-severity undici advisory in `frontend/electron`; fixed non-breaking via `npm audit fix` (lockfile-only change, 0 vulnerabilities after). `python tasks/pre_server_readiness.py` then passed all 6 checks including full pytest 350 passed.
- 2026-05-30 pre-server readiness: initial run exposed Ollama was not running; after starting `ollama serve`, `python tasks/pre_server_readiness.py` passed all 6 checks: full pytest reported 350 passed with 3 third-party GPUtil warnings, `python -m pip_audit -r requirements.txt` found no known vulnerabilities, `python -m pip check` found no broken requirements, `npm audit --prefix frontend/electron --audit-level=high` found 0 vulnerabilities, `python tasks/readiness_report.py` passed all required checks, and `python tasks/tool_readiness_smoke.py` passed 10 checks.
- `python -m py_compile tasks\pre_server_readiness.py`: passed.
- `pytest -q tests\test_pre_server_readiness.py -p no:cacheprovider`: 4 passed.
- `python -m py_compile app\resource_manager.py app\cli.py app\server.py app\config.py app\voice\stt.py app\voice\tts.py app\voice\wake_word.py app\voice\sounds.py app\computer\vision.py jarvis.py`: passed.
- `pytest tests\test_resource_manager.py tests\test_config_check.py tests\test_server_integration.py -q`: 29 passed.
- `python -m app.cli sleep --deep`: moved persisted state to DEEP_SLEEP, unloaded Ollama models, and reported 0 MB loaded-model VRAM with 0 JARVIS-owned processes.
- `python -m app.cli status`: DEEP_SLEEP, server offline, 0 MB estimated loaded-model VRAM, 0 JARVIS-owned processes, 0 loaded Ollama models.
- `npm audit --prefix frontend\electron --audit-level=high`: 0 vulnerabilities.
- Pre-server cleanup validation on 2026-05-14: `app.server` import measured about 0.56s after lazy-loading cleanup versus about 1.38s before; deep-sleep `python -m app.cli status` measured about 1.23s; full pytest reported 327 passed; `python -m pip_audit -r requirements.txt` found no known vulnerabilities; `python -m pip check` found no broken requirements; `npm audit --prefix frontend\electron --audit-level=high` found 0 vulnerabilities.
- `pytest -q tests/test_config_check.py tests/test_rag_client.py tests/test_server_integration.py tests/router_test.py tests/test_pwa_serve.py tests/test_readiness_report.py -p no:cacheprovider`: 40 passed, 1 warning.
- `python -m pip check`: no broken requirements found.
- `npm.cmd audit --audit-level=moderate --prefix frontend/electron`: 0 vulnerabilities.
- `pytest --collect-only -q -p no:cacheprovider`: 320 tests collected.
- `pytest -q -p no:cacheprovider`: 320 passed, 0 skipped, 4 warnings (third-party only: GPUtil + pygame).
- `python tasks/readiness_report.py`: all required readiness checks pass (after starting Ollama via `ollama serve`).
- `python tasks/tool_readiness_smoke.py`: 10 readiness checks passed.
- `docker --version`: failed because Docker is not installed or not on PATH in this environment.
