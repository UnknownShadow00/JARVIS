import pytest
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

from app.config import API_TOKEN_ENV, load_settings, settings
from app.server import app

client = TestClient(app)


@pytest.fixture(autouse=True)
def explicit_disposable_authority(tmp_path):
    from app.agent import runtime
    from synthetic_authority import fixture_authority
    previous,worker=runtime._authority,runtime._execution_worker
    runtime._authority=runtime._execution_worker=None
    runtime.bind_authority(fixture_authority(tmp_path/'auth/state.sqlite'))
    try:yield
    finally:
        runtime.close_authority();runtime._authority=previous;runtime._execution_worker=worker


@pytest.fixture
def api_token(monkeypatch) -> str:
    token = "test-secret-token"
    monkeypatch.setattr(settings.server, "api_token", token)
    return token


def test_empty_token_cannot_access_authority() -> None:
    assert settings.server.api_token == ""
    response = client.get("/tasks")
    assert response.status_code == 401


def test_missing_token_rejected(api_token: str) -> None:
    response = client.get("/tasks")
    assert response.status_code == 401
    assert response.json()["error"] == "Unauthorized"


def test_wrong_token_rejected(api_token: str) -> None:
    response = client.get("/tasks", headers={"Authorization": "Bearer wrong-token"})
    assert response.status_code == 401


def test_malformed_header_rejected(api_token: str) -> None:
    response = client.get("/tasks", headers={"Authorization": api_token})
    assert response.status_code == 401


def test_valid_token_accepted(api_token: str) -> None:
    response = client.get("/tasks", headers={"Authorization": f"Bearer {api_token}"})
    assert response.status_code == 200


def test_health_exempt(api_token: str) -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_ws_rejected_without_token(api_token: str) -> None:
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws"):
            pass


def test_ws_rejected_with_wrong_token(api_token: str) -> None:
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws", headers={"Authorization": "Bearer wrong-token"}):
            pass


def test_ws_rejected_with_query_token(api_token: str) -> None:
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect(f"/ws?token={api_token}"):
            pass


def test_ws_accepted_with_bearer_header(api_token: str) -> None:
    with client.websocket_connect("/ws", headers={"Authorization": f"Bearer {api_token}"}):
        pass


def test_ws_trusted_origin_accepted(api_token: str) -> None:
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Origin": f"http://127.0.0.1:{settings.server.port}",
    }
    with client.websocket_connect("/ws", headers=headers):
        pass


def test_ws_untrusted_origin_rejected_with_valid_token(api_token: str) -> None:
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Origin": "https://untrusted.example",
    }
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws", headers=headers):
            pass


def test_ws_missing_origin_allowed_for_native_client(api_token: str) -> None:
    with client.websocket_connect("/ws", headers={"Authorization": f"Bearer {api_token}"}):
        pass


def test_ue5_ws_rejected_without_token(api_token: str) -> None:
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ue5"):
            pass


def test_ue5_ws_rejects_untrusted_origin(api_token: str) -> None:
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Origin": "https://untrusted.example",
    }
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ue5", headers=headers):
            pass


def test_confirmation_route_requires_authentication(api_token: str) -> None:
    response = client.post("/confirm/unknown-request")
    assert response.status_code == 401

    authorized = client.post(
        "/confirm/unknown-request",
        headers={"Authorization": f"Bearer {api_token}"},
    )
    assert authorized.status_code == 404


def test_env_override_sets_api_token(monkeypatch) -> None:
    monkeypatch.setenv(API_TOKEN_ENV, "env-secret")
    loaded = load_settings()
    assert loaded.server.api_token == "env-secret"
