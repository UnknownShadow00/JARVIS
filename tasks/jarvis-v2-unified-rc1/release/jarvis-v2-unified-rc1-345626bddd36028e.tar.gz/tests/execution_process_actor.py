"""Independent crash helper. Only the disposable cage state path is opened."""
from pathlib import Path
import sys
import time
from datetime import UTC, datetime, timedelta

if not Path('/input/source').is_dir() or not Path('/deps').is_dir():
    raise SystemExit('isolated runner required')
sys.path[:0] = ['/input/source', '/deps']
from app.agent.authority import Authority
sys.path.insert(0,'/input')
from synthetic_authority import fixture_authority as Authority
from app.agent.execution import ExecutionPipeline, SimulatedPolicy
from app.agent.runtime import SERVICE_ACTOR

database, ready, op, stage = sys.argv[1:]
a = Authority(database, allow_simulation=True)
def fault(current):
    if current == stage:
        Path(ready).write_text(current)
        deadline = time.monotonic()+4
        while time.monotonic()<deadline:
            time.sleep(.01)
        raise RuntimeError('parent failed to kill owned child')
def storage_fault(current):
    phase = {'record_before_commit':'record', 'publish_before_commit':'publish'}.get(stage)
    if current=='before_commit' and phase:
        from app.agent.execution import phase_id
        if a._conn.execute('SELECT 1 FROM receipts WHERE request_id=?',(phase_id(op,phase),)).fetchone():
            fault(stage)
a._fault = storage_fault
p = ExecutionPipeline(a, SimulatedPolicy(SERVICE_ACTOR.scope), enabled=True, fault_hook=fault)
p.submit(SERVICE_ACTOR, op, 'crash probe', 'synthetic.echo', {'value':'crash marker'}, (datetime.now(UTC)+timedelta(minutes=1)).isoformat())
p.run_once(SERVICE_ACTOR)
raise SystemExit('fault boundary was not reached')
